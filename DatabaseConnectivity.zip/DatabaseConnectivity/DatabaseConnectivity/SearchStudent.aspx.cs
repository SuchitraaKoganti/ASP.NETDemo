﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace DatabaseConnectivity
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("Select * from Student_Master where Stud_Code=@SCode", con);
            cmd.Parameters.AddWithValue("@SCode", txtcode.Text);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            
            if(dr.HasRows)
            {
                dr.Read();
                txtname.Text = dr["Stud_Name"].ToString();
                txtdcode.Text = dr["Dept_Code"].ToString();
                txtdob.Text = dr["Stud_Dob"].ToString();
                txtaddr.Text = dr["Address"].ToString();
                txtname.Enabled = true;
                txtdcode.Enabled = true;
                txtdob.Enabled = true;
                txtaddr.Enabled = true;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data not found for Stud Code"+txtcode.Text+"');</SCRIPT>");
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("update Student_Master set Stud_Name=@SName,Dept_Code=@DCode,Stud_Dob=@DOB,Address=@Address where Stud_Code=@SCode", con);
            cmd.Parameters.AddWithValue("@SName", txtname.Text);
            cmd.Parameters.AddWithValue("@DCode", txtdcode.Text);
            cmd.Parameters.AddWithValue("@DOB",Convert.ToDateTime( txtdob.Text));
          
            cmd.Parameters.AddWithValue("@Address", txtaddr.Text);
            cmd.Parameters.AddWithValue("@SCode", txtcode.Text);
            con.Open();
            int recordafftected = cmd.ExecuteNonQuery();
            con.Close();
            if(recordafftected>0)
            {
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data updated for Stud Code" + txtcode.Text + "');</SCRIPT>");
                txtname.Enabled = false;
                txtdcode.Enabled = false;
                txtdob.Enabled = false;
                txtaddr.Enabled = false;
                btnupdate.Enabled =false;
                btndelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data not updated for Stud Code" + txtcode.Text + "');</SCRIPT>");

        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("delete from Student_Master where Stud_Code=@SCode",con);
            cmd.Parameters.AddWithValue("@SCode", txtcode.Text);
            con.Open();
            int rowsaffected = cmd.ExecuteNonQuery();
            
            if (rowsaffected > 0)
            {
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data deleted for Stud Code" + txtcode.Text + "');</SCRIPT>");
                txtname.Enabled = false;
                txtdcode.Enabled = false;
                txtdob.Enabled = false;
                txtaddr.Enabled = false;
                btnupdate.Enabled = false;
                btndelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data not deleted for Stud Code" + txtcode.Text + "');</SCRIPT>");
        }
    }
}