﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DropDownDemo
{
    public partial class Student : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SqlCommand cmd = new SqlCommand("select Stud_Code,Stud_Name from Student_master", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    //foreach (DataRow item in dt.Rows)
                    //{
                    //    ListItem li = new ListItem();
                    //    li.Value = item["Stud_Code"].ToString();
                    //    li.Text = item["Stud_Name"].ToString();
                    //    ddlstudent.Items.Add(li);
                    //}

                    ddlstudent.DataSource = dt;
                    ddlstudent.DataTextField = "Stud_Name";
                    ddlstudent.DataValueField = "Stud_Code";
                    ddlstudent.DataBind();
                }
            }
        }
        protected void ddlstudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from Student_master where Stud_Code=@Stud_Code", con);
            cmd.Parameters.AddWithValue("@Stud_Code", ddlstudent.SelectedValue);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if(dr.HasRows)
            {
                //dr.Read();
                //var stud = new { StudCode = dr["Stud_Code"], StudName = dr["Stud_Name"], DeptCode = dr["Dept_Code"], DateofBirth = dr["Stud_Dob"], Address = dr["Address"] };
                dt.Load(dr);
            }
            con.Close();
            dvStudent.DataSource = dt;
            dvStudent.DataBind();
        }
    }
}