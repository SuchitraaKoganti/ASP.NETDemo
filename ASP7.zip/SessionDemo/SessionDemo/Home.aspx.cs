﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SessionDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                Session["counter"] = 0;
                lblsessionid.Text = Session.SessionID;
                lblsessioncounter.Text = Session["counter"].ToString();
            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            int cnt = (int)Session["counter"];
            cnt = cnt + 1;
            Session["counter"] = cnt;
            lblsessioncounter.Text = Session["counter"].ToString();
        }
    }
}